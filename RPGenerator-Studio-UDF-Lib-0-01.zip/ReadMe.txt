README.txt FOR RPGenerator Concept Demo v. 0.01

*****FOR IN GAME HELP USE /help IN THE COMMAND LINE*********

By: Neo_ (aka coderusa)
neotuber1776@usa.com <-- BUG REPORTS AND GAME ISSUES ONLY

I can be found on IRC chat. (IRC user on Esper is Neo_Nemesis)
Server: irc.esper.net
Port: 6667
Channel: #CodeUSA

Feel free to stop by the chat. If you have issues or bug reports you may send
the info to me via private message on IRC. (If I'm online.) Otherwise use
the e-mail or autoit forum thread.

Thanks To: UEZ, TheDcoder and Andreik (From Autoit forums along with the whole Autoit forum community)
Thanks To: vurtual_, Friithian, siiseli, and Namelesswonder (from EsperNet #minecraft chat)

PLEASE NOTE THIS PROGRAM IS NOT FINISHED.
THIS IS NOT A FULL GAME PROGRAM. 
THERE IS NO SOUND EFFECTS OR MUSIC (YET).

This is a concept demonstration of RPGenerator game engine. The purpose of this program is to test the
functions, mechanics and code of the game, TO THIS POINT.

Other features, functions and mechanics will be developed in the future.

If you have any bugs, please contain all info available, including your operating system and specs, and
details on how to recreate the issue.

If you find errors in the source code, you may fix them in your copy, but please also include all information
on source code errors in your report. 

SEND ALL BUG REPORTS AND ISSUES TO: neotuber1776@usa.com

NOTE TO AUTOIT FORUM USERS AND PROGRAMMERS: You may post your bugs in the developer thread created for this program on the
autoit forums. 