RPGenerator CONCEPT DEMO v. 0.01 SOURCE PACKAGE

CONTAINS GAME DEMO SOURCE CODE FILES
CONTAINS RPGSTUDIO UDF SOURCE FILES
CONTAINS ALL IMAGES AND FILES FOR THE GAME DEMO

INSTALL INSTRUCTIONS

PLACE RPGSOURCE in C:\

Open and run INSTALL.au3 in SciTE to install core files

Open and run UNINSTALL.au3 in SciTE to uninstall files

After you run INSTALL.au3, the main program starts from RPG-EXE.au3


