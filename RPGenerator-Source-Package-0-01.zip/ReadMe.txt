RPGenerator CONCEPT DEMO v. 0.01 SOURCE PACKAGE

CONTAINS GAME DEMO SOURCE CODE FILES
CONTAINS RPGSTUDIO UDF SOURCE FILES
CONTAINS ALL IMAGES AND FILES FOR THE GAME DEMO

INSTALL INSTRUCTIONS

1) Put RPGSOURCE folder in C:\  - ( it MUST be C:\RPGSOURCE\ )

2) Run Install.au3 (Running Install.exe should acheive the same result, will place the executable in C:\RPGenerator\ and shortcut on desktop, you may delete the executable and shortcut if you are only going to run off the scripts) All core files are placed in C:\Program Data\.RPG\ by the install script

3) Run RPG-EXE.au3

NOTE: If needed, you may also uninstall all files by running Uninstall.au3.

NOTE: USE /help IN THE PROGRAM COMMAND LINE TO VEIW HELP INFO